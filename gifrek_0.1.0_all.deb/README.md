# gifrek
Create GIF screencast and upload to gyazo.com on Linux
